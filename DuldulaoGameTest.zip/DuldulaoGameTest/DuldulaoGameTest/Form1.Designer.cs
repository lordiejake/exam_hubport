﻿namespace DuldulaoGameTest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button12 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Brawler_MinimumHealth_Left = new System.Windows.Forms.Label();
            this.Left_Original_Health = new System.Windows.Forms.Label();
            this.CharacterLeftSide = new System.Windows.Forms.Label();
            this.left_side_attack = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.left_side_evade = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.left_side_health = new System.Windows.Forms.Label();
            this.left_side_speed = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.left_side_defense = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Brawler_MinimumHealth = new System.Windows.Forms.Label();
            this.Original_Health = new System.Windows.Forms.Label();
            this.CharacterRightSide = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.right_side_attack = new System.Windows.Forms.Label();
            this.right_side_evade = new System.Windows.Forms.Label();
            this.right_side_health = new System.Windows.Forms.Label();
            this.right_side_speed = new System.Windows.Forms.Label();
            this.right_side_defense = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button13 = new System.Windows.Forms.Button();
            this.player2remaining_turn = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.player1remaining_turn = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.Left_New_Attack_Ninja = new System.Windows.Forms.Label();
            this.Right_New_Attack_Ninja = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Location = new System.Drawing.Point(12, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(677, 430);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Game Zone";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.pictureBox3.Location = new System.Drawing.Point(330, 27);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(10, 391);
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button12);
            this.groupBox3.Controls.Add(this.button9);
            this.groupBox3.Controls.Add(this.button7);
            this.groupBox3.Controls.Add(this.button5);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.listBox2);
            this.groupBox3.Location = new System.Drawing.Point(6, 19);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(310, 405);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Select Warriors [Player 1]";
            // 
            // button12
            // 
            this.button12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button12.Location = new System.Drawing.Point(165, 381);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(139, 24);
            this.button12.TabIndex = 18;
            this.button12.Text = "[TEST]";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Visible = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button9
            // 
            this.button9.Enabled = false;
            this.button9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button9.Location = new System.Drawing.Point(7, 381);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(139, 24);
            this.button9.TabIndex = 15;
            this.button9.Text = "[Start] [Player 1 Selected]";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(6, 177);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(139, 24);
            this.button7.TabIndex = 14;
            this.button7.Text = "[    Refresh    ]";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(165, 146);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(139, 25);
            this.button5.TabIndex = 13;
            this.button5.Text = "[    Clear    ]";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Enabled = false;
            this.button4.Location = new System.Drawing.Point(6, 356);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(139, 25);
            this.button4.TabIndex = 12;
            this.button4.Text = "Select Random Players";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.groupBox5.Controls.Add(this.Left_New_Attack_Ninja);
            this.groupBox5.Controls.Add(this.Brawler_MinimumHealth_Left);
            this.groupBox5.Controls.Add(this.Left_Original_Health);
            this.groupBox5.Controls.Add(this.CharacterLeftSide);
            this.groupBox5.Controls.Add(this.left_side_attack);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.left_side_evade);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.left_side_health);
            this.groupBox5.Controls.Add(this.left_side_speed);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.left_side_defense);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Location = new System.Drawing.Point(6, 214);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(298, 140);
            this.groupBox5.TabIndex = 11;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Character Details [Player 1]";
            // 
            // Brawler_MinimumHealth_Left
            // 
            this.Brawler_MinimumHealth_Left.AutoSize = true;
            this.Brawler_MinimumHealth_Left.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Brawler_MinimumHealth_Left.Location = new System.Drawing.Point(128, 82);
            this.Brawler_MinimumHealth_Left.Name = "Brawler_MinimumHealth_Left";
            this.Brawler_MinimumHealth_Left.Size = new System.Drawing.Size(23, 13);
            this.Brawler_MinimumHealth_Left.TabIndex = 19;
            this.Brawler_MinimumHealth_Left.Text = "----";
            this.Brawler_MinimumHealth_Left.Visible = false;
            // 
            // Left_Original_Health
            // 
            this.Left_Original_Health.AutoSize = true;
            this.Left_Original_Health.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Left_Original_Health.Location = new System.Drawing.Point(128, 67);
            this.Left_Original_Health.Name = "Left_Original_Health";
            this.Left_Original_Health.Size = new System.Drawing.Size(23, 13);
            this.Left_Original_Health.TabIndex = 19;
            this.Left_Original_Health.Text = "----";
            this.Left_Original_Health.Visible = false;
            // 
            // CharacterLeftSide
            // 
            this.CharacterLeftSide.AutoSize = true;
            this.CharacterLeftSide.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CharacterLeftSide.Location = new System.Drawing.Point(58, 16);
            this.CharacterLeftSide.Name = "CharacterLeftSide";
            this.CharacterLeftSide.Size = new System.Drawing.Size(23, 13);
            this.CharacterLeftSide.TabIndex = 18;
            this.CharacterLeftSide.Text = "----";
            this.CharacterLeftSide.Click += new System.EventHandler(this.CharacterLeftSide_Click);
            // 
            // left_side_attack
            // 
            this.left_side_attack.AutoSize = true;
            this.left_side_attack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.left_side_attack.Location = new System.Drawing.Point(58, 81);
            this.left_side_attack.Name = "left_side_attack";
            this.left_side_attack.Size = new System.Drawing.Size(23, 13);
            this.left_side_attack.TabIndex = 16;
            this.left_side_attack.Text = "----";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(8, 16);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(44, 13);
            this.label24.TabIndex = 17;
            this.label24.Text = "NAME: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 82);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Attack:";
            // 
            // left_side_evade
            // 
            this.left_side_evade.AutoSize = true;
            this.left_side_evade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.left_side_evade.Location = new System.Drawing.Point(58, 124);
            this.left_side_evade.Name = "left_side_evade";
            this.left_side_evade.Size = new System.Drawing.Size(23, 13);
            this.left_side_evade.TabIndex = 19;
            this.left_side_evade.Text = "----";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 125);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Evade:";
            // 
            // left_side_health
            // 
            this.left_side_health.AutoSize = true;
            this.left_side_health.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.left_side_health.Location = new System.Drawing.Point(58, 67);
            this.left_side_health.Name = "left_side_health";
            this.left_side_health.Size = new System.Drawing.Size(23, 13);
            this.left_side_health.TabIndex = 15;
            this.left_side_health.Text = "----";
            // 
            // left_side_speed
            // 
            this.left_side_speed.AutoSize = true;
            this.left_side_speed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.left_side_speed.Location = new System.Drawing.Point(58, 110);
            this.left_side_speed.Name = "left_side_speed";
            this.left_side_speed.Size = new System.Drawing.Size(23, 13);
            this.left_side_speed.TabIndex = 18;
            this.left_side_speed.Text = "----";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Health: ";
            // 
            // left_side_defense
            // 
            this.left_side_defense.AutoSize = true;
            this.left_side_defense.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.left_side_defense.Location = new System.Drawing.Point(58, 95);
            this.left_side_defense.Name = "left_side_defense";
            this.left_side_defense.Size = new System.Drawing.Size(23, 13);
            this.left_side_defense.TabIndex = 17;
            this.left_side_defense.Text = "----";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 111);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "Speed:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 96);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "Defense:";
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(6, 146);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(139, 25);
            this.button2.TabIndex = 4;
            this.button2.Text = "[    Attack    ]";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(6, 19);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(298, 121);
            this.listBox2.TabIndex = 2;
            this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button11);
            this.groupBox2.Controls.Add(this.button10);
            this.groupBox2.Controls.Add(this.button8);
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.listBox1);
            this.groupBox2.Location = new System.Drawing.Point(356, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(310, 405);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Select Warriors [Player 2]";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // button11
            // 
            this.button11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button11.Location = new System.Drawing.Point(151, 381);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(139, 24);
            this.button11.TabIndex = 17;
            this.button11.Text = "[TEST]";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Visible = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.Enabled = false;
            this.button10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button10.Location = new System.Drawing.Point(6, 381);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(139, 24);
            this.button10.TabIndex = 16;
            this.button10.Text = "[Start] [Player 2 Selected]";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(6, 177);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(139, 24);
            this.button8.TabIndex = 15;
            this.button8.Text = "[    Refresh    ]";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(165, 146);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(139, 25);
            this.button6.TabIndex = 14;
            this.button6.Text = "[     Clear    ]";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button3
            // 
            this.button3.Enabled = false;
            this.button3.Location = new System.Drawing.Point(6, 356);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(139, 25);
            this.button3.TabIndex = 11;
            this.button3.Text = "Select Random Players";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.groupBox4.Controls.Add(this.Right_New_Attack_Ninja);
            this.groupBox4.Controls.Add(this.Brawler_MinimumHealth);
            this.groupBox4.Controls.Add(this.Original_Health);
            this.groupBox4.Controls.Add(this.CharacterRightSide);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.right_side_attack);
            this.groupBox4.Controls.Add(this.right_side_evade);
            this.groupBox4.Controls.Add(this.right_side_health);
            this.groupBox4.Controls.Add(this.right_side_speed);
            this.groupBox4.Controls.Add(this.right_side_defense);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Location = new System.Drawing.Point(6, 214);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(298, 140);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Character Details [Player 2]";
            // 
            // Brawler_MinimumHealth
            // 
            this.Brawler_MinimumHealth.AutoSize = true;
            this.Brawler_MinimumHealth.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Brawler_MinimumHealth.Location = new System.Drawing.Point(141, 82);
            this.Brawler_MinimumHealth.Name = "Brawler_MinimumHealth";
            this.Brawler_MinimumHealth.Size = new System.Drawing.Size(23, 13);
            this.Brawler_MinimumHealth.TabIndex = 18;
            this.Brawler_MinimumHealth.Text = "----";
            this.Brawler_MinimumHealth.Visible = false;
            // 
            // Original_Health
            // 
            this.Original_Health.AutoSize = true;
            this.Original_Health.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Original_Health.Location = new System.Drawing.Point(141, 68);
            this.Original_Health.Name = "Original_Health";
            this.Original_Health.Size = new System.Drawing.Size(23, 13);
            this.Original_Health.TabIndex = 17;
            this.Original_Health.Text = "----";
            this.Original_Health.Visible = false;
            // 
            // CharacterRightSide
            // 
            this.CharacterRightSide.AutoSize = true;
            this.CharacterRightSide.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CharacterRightSide.Location = new System.Drawing.Point(64, 16);
            this.CharacterRightSide.Name = "CharacterRightSide";
            this.CharacterRightSide.Size = new System.Drawing.Size(23, 13);
            this.CharacterRightSide.TabIndex = 16;
            this.CharacterRightSide.Text = "----";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(3, 16);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(44, 13);
            this.label22.TabIndex = 15;
            this.label22.Text = "NAME: ";
            // 
            // right_side_attack
            // 
            this.right_side_attack.AutoSize = true;
            this.right_side_attack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.right_side_attack.Location = new System.Drawing.Point(64, 81);
            this.right_side_attack.Name = "right_side_attack";
            this.right_side_attack.Size = new System.Drawing.Size(23, 13);
            this.right_side_attack.TabIndex = 11;
            this.right_side_attack.Text = "----";
            // 
            // right_side_evade
            // 
            this.right_side_evade.AutoSize = true;
            this.right_side_evade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.right_side_evade.Location = new System.Drawing.Point(64, 124);
            this.right_side_evade.Name = "right_side_evade";
            this.right_side_evade.Size = new System.Drawing.Size(23, 13);
            this.right_side_evade.TabIndex = 14;
            this.right_side_evade.Text = "----";
            // 
            // right_side_health
            // 
            this.right_side_health.AutoSize = true;
            this.right_side_health.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.right_side_health.Location = new System.Drawing.Point(64, 67);
            this.right_side_health.Name = "right_side_health";
            this.right_side_health.Size = new System.Drawing.Size(23, 13);
            this.right_side_health.TabIndex = 10;
            this.right_side_health.Text = "----";
            // 
            // right_side_speed
            // 
            this.right_side_speed.AutoSize = true;
            this.right_side_speed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.right_side_speed.Location = new System.Drawing.Point(64, 110);
            this.right_side_speed.Name = "right_side_speed";
            this.right_side_speed.Size = new System.Drawing.Size(23, 13);
            this.right_side_speed.TabIndex = 13;
            this.right_side_speed.Text = "----";
            // 
            // right_side_defense
            // 
            this.right_side_defense.AutoSize = true;
            this.right_side_defense.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.right_side_defense.Location = new System.Drawing.Point(64, 95);
            this.right_side_defense.Name = "right_side_defense";
            this.right_side_defense.Size = new System.Drawing.Size(23, 13);
            this.right_side_defense.TabIndex = 12;
            this.right_side_defense.Text = "----";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Attack:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 124);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Evade:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Health: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Speed:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Defense:";
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(6, 146);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(139, 25);
            this.button1.TabIndex = 3;
            this.button1.Text = "[    Attack    ]";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(6, 19);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(298, 121);
            this.listBox1.TabIndex = 2;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.White;
            this.groupBox6.Controls.Add(this.button13);
            this.groupBox6.Controls.Add(this.player2remaining_turn);
            this.groupBox6.Controls.Add(this.label14);
            this.groupBox6.Controls.Add(this.player1remaining_turn);
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Location = new System.Drawing.Point(12, 460);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(677, 68);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Game Result";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(507, 38);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(139, 24);
            this.button13.TabIndex = 18;
            this.button13.Text = "[   View Results   ]";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Visible = false;
            // 
            // player2remaining_turn
            // 
            this.player2remaining_turn.AutoSize = true;
            this.player2remaining_turn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player2remaining_turn.Location = new System.Drawing.Point(446, 15);
            this.player2remaining_turn.Name = "player2remaining_turn";
            this.player2remaining_turn.Size = new System.Drawing.Size(14, 13);
            this.player2remaining_turn.TabIndex = 23;
            this.player2remaining_turn.Text = "0";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(365, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(85, 13);
            this.label14.TabIndex = 22;
            this.label14.Text = "Player 2 TURN: ";
            // 
            // player1remaining_turn
            // 
            this.player1remaining_turn.AutoSize = true;
            this.player1remaining_turn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player1remaining_turn.Location = new System.Drawing.Point(91, 16);
            this.player1remaining_turn.Name = "player1remaining_turn";
            this.player1remaining_turn.Size = new System.Drawing.Size(14, 13);
            this.player1remaining_turn.TabIndex = 21;
            this.player1remaining_turn.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 13);
            this.label12.TabIndex = 20;
            this.label12.Text = "Player 1 TURN: ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.pictureBox1.Location = new System.Drawing.Point(2, -5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(698, 27);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.pictureBox2.Location = new System.Drawing.Point(2, 534);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(698, 27);
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.pictureBox4.Location = new System.Drawing.Point(2, 57);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(10, 391);
            this.pictureBox4.TabIndex = 5;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.pictureBox5.Location = new System.Drawing.Point(690, 51);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(10, 391);
            this.pictureBox5.TabIndex = 6;
            this.pictureBox5.TabStop = false;
            // 
            // Left_New_Attack_Ninja
            // 
            this.Left_New_Attack_Ninja.AutoSize = true;
            this.Left_New_Attack_Ninja.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Left_New_Attack_Ninja.Location = new System.Drawing.Point(186, 82);
            this.Left_New_Attack_Ninja.Name = "Left_New_Attack_Ninja";
            this.Left_New_Attack_Ninja.Size = new System.Drawing.Size(23, 13);
            this.Left_New_Attack_Ninja.TabIndex = 20;
            this.Left_New_Attack_Ninja.Text = "----";
            // 
            // Right_New_Attack_Ninja
            // 
            this.Right_New_Attack_Ninja.AutoSize = true;
            this.Right_New_Attack_Ninja.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Right_New_Attack_Ninja.Location = new System.Drawing.Point(211, 81);
            this.Right_New_Attack_Ninja.Name = "Right_New_Attack_Ninja";
            this.Right_New_Attack_Ninja.Size = new System.Drawing.Size(23, 13);
            this.Right_New_Attack_Ninja.TabIndex = 19;
            this.Right_New_Attack_Ninja.Text = "----";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(701, 554);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Game";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label left_side_attack;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label left_side_evade;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label left_side_health;
        private System.Windows.Forms.Label left_side_speed;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label left_side_defense;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label right_side_attack;
        private System.Windows.Forms.Label right_side_evade;
        private System.Windows.Forms.Label right_side_health;
        private System.Windows.Forms.Label right_side_speed;
        private System.Windows.Forms.Label right_side_defense;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label CharacterLeftSide;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label CharacterRightSide;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label player2remaining_turn;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label player1remaining_turn;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label Original_Health;
        private System.Windows.Forms.Label Brawler_MinimumHealth;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label Brawler_MinimumHealth_Left;
        private System.Windows.Forms.Label Left_Original_Health;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label Left_New_Attack_Ninja;
        private System.Windows.Forms.Label Right_New_Attack_Ninja;
    }
}

